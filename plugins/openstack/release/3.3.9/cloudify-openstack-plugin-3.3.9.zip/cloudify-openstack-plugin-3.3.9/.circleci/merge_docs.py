from ecosystem_cicd_tools.github_stuff import merge_documentation_pulls

if __name__ == '__main__':
    merge_documentation_pulls()

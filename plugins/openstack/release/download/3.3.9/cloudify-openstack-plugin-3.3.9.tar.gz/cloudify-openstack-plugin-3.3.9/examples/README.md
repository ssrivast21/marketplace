# Cloudify openstack Plugin Examples

These blueprints are used primarily for testing use cases.

The local blueprints are using for testing in a special environment. They have
several syntactical peculiarities and are not therefore representative of best
practices.

The manager blueprints are good for learning best practices.
